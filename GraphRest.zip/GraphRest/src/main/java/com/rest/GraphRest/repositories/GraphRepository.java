package com.rest.GraphRest.repositories;

import com.rest.GraphRest.domain.Graph;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GraphRepository extends JpaRepository<Graph, Long> {
}
