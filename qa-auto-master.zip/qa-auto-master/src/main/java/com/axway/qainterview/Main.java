package com.axway.qainterview;

import java.util.Set;

public class Main {

	public static void main(String[] args) {
		Graph graph = new Graph();
		graph.addVertex("1");
		graph.addVertex("2");
		graph.addVertex("3");
		graph.addVertex("4");
		graph.addVertex("5");

		graph.addEdge("1", "5");
		graph.addEdge("2", "3");
		graph.addEdge("5", "4");
		graph.addEdge("4", "3");
		//graph.addEdge("1", "2");

		Set<String> traversal = GraphTraversal.breadthFirstTraversal(graph, "1");
		for (String key : traversal) {
			System.out.println(key);
		}

		System.out.println("\n");

		Set<String> depthTraversal = GraphTraversal.depthFirstTraversal(graph, "1");
		for (String key : depthTraversal) {
			System.out.println(key);
		}

		Tree t = new Tree();
		t.insert(1);
		t.insert(3);
		t.insert(5);
		t.insert(12);
		t.insert(11);
		t.insert(6);
		t.insert(4);
		t.insert(7);
		t.display(t.root);

		if (t.find(7)) {
		    t.delete(7);
		    System.out.println("\nTree if node with id 7 is found: ");
            t.display(t.root);
        }
	}
}
