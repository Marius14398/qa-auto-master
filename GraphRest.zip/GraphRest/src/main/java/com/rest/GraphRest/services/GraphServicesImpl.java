package com.rest.GraphRest.services;

import com.rest.GraphRest.domain.Graph;
import com.rest.GraphRest.repositories.GraphRepository;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class GraphServicesImpl implements GraphServices{
    private final GraphRepository graphRepository;

    public GraphServicesImpl(GraphRepository graphRepository) {
        this.graphRepository = graphRepository;
    }

    public Set<String> breadthFirstTraversal(Graph graph, String root) {
        Set<String> visited = new LinkedHashSet<>();
        Queue<String> queue = new LinkedList<>();
        queue.add(root);
        visited.add(root);
        while (!queue.isEmpty()) {
            String vertex = queue.poll();
            for (Graph.Vertex v : graph.getAdjVertices(vertex)) {
                if (!visited.contains(v.label)) {
                    visited.add(v.label);
                    queue.add(v.label);
                }
            }
        }
        return visited;
    }

    public Set<String> depthFirstTraversal(Graph graph, String root) {
        Set<String> visited = new LinkedHashSet<>();
        Stack<String> stack = new Stack<>();
        visited.add(root);
        stack.push(root);

        while (!stack.isEmpty()) {
            String vertex = stack.peek();
            stack.pop();

            if (!visited.contains(vertex)) {
                visited.add(vertex);
            }

            for (Graph.Vertex v : graph.getAdjVertices(vertex)) {
                if (!visited.contains(v.label)) {
                    stack.add(v.label);
                }
            }
        }
        return visited;
    }
}
