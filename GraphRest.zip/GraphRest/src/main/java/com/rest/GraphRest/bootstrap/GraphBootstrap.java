package com.rest.GraphRest.bootstrap;

import com.rest.GraphRest.domain.Graph;
import com.rest.GraphRest.repositories.GraphRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;

@Component
public class GraphBootstrap implements CommandLineRunner {
    private final GraphRepository graphRepository;

    @NotNull
    public GraphBootstrap(GraphRepository graphRepository) {
        this.graphRepository = graphRepository;
    }


    @Override
    public void run(String... args) throws Exception {
        System.out.println("Creating a new graph");

        Graph graph = new Graph();
        graph.addVertex("1");
        graph.addVertex("2");
        graph.addVertex("3");
        graph.addVertex("4");
        graph.addVertex("5");

        graph.addEdge("1", "5");
        graph.addEdge("2", "3");
        graph.addEdge("5", "4");
        graph.addEdge("4", "3");
        //graph.addEdge("1", "2");
        graphRepository.save(graph);

        System.out.println("Number of graphs saved: " + graphRepository.count());
    }
}
