package com.rest.GraphRest.controllers;

import com.rest.GraphRest.domain.Graph;
import com.rest.GraphRest.services.GraphServices;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;
import java.util.Set;

@RestController
@RequestMapping(GraphController.BASE_URL)
public class GraphController {
    public static final String BASE_URL = "/api/v1/graph";
    private final GraphServices graphServices;

    @NotNull
    public GraphController(GraphServices graphServices) {
        this.graphServices = graphServices;
    }

    @GetMapping("/bfs")
    Set<String> breadthFirstTraversal(Graph graph, String root) {
        return graphServices.breadthFirstTraversal(graph, root);
    }

    @GetMapping("/dfs")
    Set<String> depthFirstTraversal(Graph graph, String root) {
        return graphServices.depthFirstTraversal(graph, root);
    }
}
