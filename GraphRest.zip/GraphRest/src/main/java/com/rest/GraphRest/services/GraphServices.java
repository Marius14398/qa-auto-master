package com.rest.GraphRest.services;

import com.rest.GraphRest.domain.Graph;

import java.util.Set;

public interface GraphServices {
    Set<String> breadthFirstTraversal(Graph graph, String root);
    Set<String> depthFirstTraversal(Graph graph, String root);
}
